
package pacman;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Display {
     private JFrame frame;
      private JTable table;
      public Display(){
        frame = new JFrame();
        frame.setBounds(100, 100, 900, 500);
        frame.getContentPane().setLayout(null);
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(10, 36, 890, 314);
        frame.getContentPane().add(scrollPane);
        table = new JTable();
        scrollPane.setViewportView(table);
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            String urll="jdbc:mysql://localhost/PacmanScore";
            Connection conn=DriverManager.getConnection(urll,"root","");
            Statement stm=conn.createStatement();
            ResultSet rs=stm.executeQuery("SELECT * FROM `score`");
            ResultSetMetaData rsd=rs.getMetaData();
            DefaultTableModel mod=(DefaultTableModel)table.getModel();
            int cols=rsd.getColumnCount();
            String[] colname=new String[cols];
            mod.setColumnIdentifiers(colname);
            int score;
            while(rs.next()){
                score=rs.getInt(1);
                String[]op={Integer.toString(score)};
                for(String j:op)
                    System.out.print(j+"\t\t");
                mod.addRow(op);
                }
            stm.close();
            conn.close();}
        catch(Exception e){}
        frame.setVisible(true);
    }}

